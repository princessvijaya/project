const express = require("express");
const app = express();
const port = 8080;

app.use(bodyparser.urlencoded({extended: true}));

app.get("/", function (req, res) {
  res.send("<h1>Hello World</h1>");
});

app.post("/", function (req, res) {
var age = number(req.body.n1) / 15;
res.send("your age is in dog age: " + age " + dog years"
});

app.listen(port);
